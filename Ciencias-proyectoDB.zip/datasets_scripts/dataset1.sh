#!/bin/bash

CSV="personas.csv"

echo "Insertando el primer dataset"
cd ..
echo "El dataset se esta introduciendo en .csv"
echo "El .csv esta en la ruta:"
pwd

if [ -f $CSV ]
then
  rm -f personas.csv
else
  :  
fi


echo "10, Kevin" >> personas.csv
echo "30, Nicolas" >> personas.csv
echo "25, Tomas" >> personas.csv
echo "4, Simar" >> personas.csv

echo "Se ha introducido el dataset de manera desorganizada, ejecute el programa para organizarlo y probar con el"


